cmd /min /C "set __COMPAT_LAYER=RunAsInvoker && start "" "sol.exe""
 