cmd /min /C "set __COMPAT_LAYER=RunAsInvoker && start "" "snake.exe""
 