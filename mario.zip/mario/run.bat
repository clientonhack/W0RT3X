cmd /min /C "set __COMPAT_LAYER=RunAsInvoker && start "" "mario.exe""
 