cmd /min /C "set __COMPAT_LAYER=RunAsInvoker && start "" "tank_battle.exe""
