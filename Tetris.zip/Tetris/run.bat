cmd /min /C "set __COMPAT_LAYER=RunAsInvoker && start "" "Tetris.exe""
 